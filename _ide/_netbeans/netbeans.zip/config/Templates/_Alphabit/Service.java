/*******************************************************************************
 * ${nameAndExt}
 * Servicio de ${name} 
 *
 *       @author  ${user}
 * @creationDate  ${date}
 * {nextEntry}
<#assign licenseFirst = " *******************************************************************************">
<#assign licensePrefix = " * ">
<#assign licenseLast = " *******************************************************************************/">
<#include "${myLicensePath}">

<#if package?? && package != "">
package ${package};

import com.uxmalsoft.commons.log.SystemLog;
import com.uxmalsoft.config.Params;
import org.alphabit.config.SystemParams;
import org.alphabit.persistence.model.sys.User;
import org.alphabit.services.BaseService;

</#if>
/**
 * <p>Servicio ${name}</p>
 * @author  ${user}
 * @since   ${firstVersion}
 * @version ${version}
 */
public class ${name} extends BaseService {

    //------------------------------------------------------
    // Attributes
    //------------------------------------------------------
   
    
    //------------------------------------------------------
    // Constructors
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Constructors">
    public ${name}(){
    
    }//empty

    public ${name}(User user){
        super(user);
        -- Incluir la misma inicializacion
    }//empty
    //</editor-fold>
    
    //------------------------------------------------------
    // Getters & Setters
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Getters & Setters">
    
    //</editor-fold>
    
    //------------------------------------------------------
    // Methods and Functions
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Methods and Functions">
    
    //</editor-fold>
    
    //------------------------------------------------------
    // None
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="None">
    
    //</editor-fold>
    
}//class
