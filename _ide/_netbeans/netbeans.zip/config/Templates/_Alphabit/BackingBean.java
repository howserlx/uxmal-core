/*******************************************************************************
 * ${nameAndExt}
 * Bean de ${name} 
 *
 *       @author  ${user}
 * @creationDate  ${date}
 * {nextEntry}
<#assign licenseFirst = " *******************************************************************************">
<#assign licensePrefix = " * ">
<#assign licenseLast = " *******************************************************************************/">
<#include "${myLicensePath}">

<#if package?? && package != "">
package ${package};

import com.uxmalsoft.commons.log.SystemLog;
import com.uxmalsoft.commons.utils.StringUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import org.alphabit.beans.BaseController;
import org.alphabit.core.Module;
import org.alphabit.enums.SystemEnums;
import org.alphabit.persistence.model.sys.User;

</#if>
/**
 * <p>Bean de ${name}</p>
 * @author  ${user}
 * @since   ${firstVersion}
 * @version ${version}
 */
@ManagedBean(name = )
@ViewScoped
public class ${name} extends BaseController {

    //------------------------------------------------------
    // Attributes
    //------------------------------------------------------

    //Objects
    private --Object selectedObj;   //Objeto seleccionado
    private --Object searchObj;     //Objeto para filtros

    //Aux
    
    //Data
    private List<--Object> all--Objects;
    
    //Servicios

    //Filtros Dropdown´s
    
    //Objetos Dropdown´s

    
    //------------------------------------------------------
    // Constructors
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Constructors">
    public ${name}(){
        super(Module.);  
        Service = new Service();
        
        //SearchId
        searchObj = new --Object();
        

        FacesContext context = FacesContext.getCurrentInstance();
        
        //Editable
        String pageEd = context.getExternalContext()
                     .getRequestParameterMap().get("pageEd");
            try{
                editPage = new Boolean(pageEd);
            }catch(Exception ex){
                SystemLog.writeException(ex);
            }
        
        //ObjId
        String objId = context.getExternalContext()
                     .getRequestParameterMap().get("objId");
        
        
        //New or Edit
        if(objId!=null)
            //Edit
           loadItemFromId(objId);
        else{
            //New
            selectedObj = new --Object();
            selectedObj.setIdEnterprise(getCurrentEnterprise());
            selectedObj.setIdUser(getLoggedUser());
            
        }
            
    }//empty

    @PostConstruct
    public void init() {
        
        
    }//init

    //</editor-fold>
   
    
    //------------------------------------------------------
    // Getters & Setters
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Getters & Setters">
    
    public List<--Object> getAll--Objects() {
        if(all--Objects==null)
           all--Objects = listAll--Objects();
        return all--Objects;
    }//getAll--Objects

    /**
     * Se esta editando un objeto seleccionado
     * algunos campos de un obj ya creado no deben editarse
     * @return 
     */
    public boolean editObj(){
        return (selectedObj!=null && selectedObj.getId()!=null && selectedObj.getId()>0);

    }//editObj
    
    public --Object getSelectedObj() {
        return selectedObj;
    }

    public void setSelectedObj(--Object selectedObj) {
        this.selectedObj = selectedObj;
    }

    public --Object getSearchObj() {
        return selectedObj;
    }

    public void setSearchObj(--Object searchObj) {
        this.searchObj = searchObj;
    }


    //</editor-fold>
    
    //------------------------------------------------------
    // Methods and Functions
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Methods and Functions">
    
    /**
     * List All --Objects
     * @return 
     */
    public List<--Object> listAll--Objects() {
        List<--Object> list = new ArrayList<--Object>();
        try {
            list = service.
        } catch (Exception ex) {
            SystemLog.writeException(ex);
        }
        return list;
    } //listAll--Objects

    //</editor-fold>
    

    //------------------------------------------------------
    // DropDowns
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="DropDown">
    
    //</editor-fold>


    //------------------------------------------------------
    // Permission
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Permission">
    //Reglas especiales de permisos
    /**
     * Puede ver/buscar
     * @return 
     */
    @Override
    public boolean allowView(){
        return hasPermission(SystemEnums.PERMISSION.VIEW);
    }//allowView
    
    public boolean allowView(--Object obj){
        return hasPermission(SystemEnums.PERMISSION.VIEW);
    }//allowView
    
    /**
     * Puede agregar
     * @return 
     */
    @Override
    public boolean allowAdd(){
        return hasPermission(SystemEnums.PERMISSION.ADD);
    }//allowAdd
    
    public boolean allowAdd(--Object obj){
        return hasPermission(SystemEnums.PERMISSION.ADD);
    }//allowAdd
    
    /**
     * Puede agregar
     * @return 
     */
    @Override
    public boolean allowEdit(){
        return hasPermission(SystemEnums.PERMISSION.EDIT);
    }//allowEdit
    
    public boolean allowEdit(--Object obj){
        return hasPermission(SystemEnums.PERMISSION.EDIT);
    }//allowEdit
    
    /**
     * Puede agregar o editar
     * @return 
     */
    @Override
    public boolean allowSave(){
        if(!editPage)
            return false;
        return (hasPermission(SystemEnums.PERMISSION.ADD) || hasPermission(SystemEnums.PERMISSION.EDIT));
    }//allowSave
    
    public boolean allowSave(--Object obj){
        if(!editPage)
            return false;
        return (hasPermission(SystemEnums.PERMISSION.ADD) || hasPermission(SystemEnums.PERMISSION.EDIT));
    }//allowSave

    /**
     * Puede eliminar
     * @return 
     */
    @Override
    public boolean allowDelete(){
        return hasPermission(SystemEnums.PERMISSION.DELETE);
    }//allowDelete
    
    public boolean allowDelete(--Object obj){
        return hasPermission(SystemEnums.PERMISSION.DELETE);
    }//allowDelete
    
    /**
     * Puede importar/upload
     * @return 
     */
    @Override
    public boolean allowImport(){
        return hasPermission(SystemEnums.PERMISSION.IMPORT);
    }//allowImport
    
    public boolean allowImport(--Object obj){
        return hasPermission(SystemEnums.PERMISSION.IMPORT);
    }//allowImport
    
    /**
     * Puede exportar/descargar
     * @return 
     */
    @Override
    public boolean allowExport(){
        return hasPermission(SystemEnums.PERMISSION.EXPORT);
    }//allowExport
    
    public boolean allowExport(--Object obj){
        return hasPermission(SystemEnums.PERMISSION.EXPORT);
    }//allowExport
    
    /**
     * Puede hacer reportes/mapas
     * @return 
     */
    @Override
    public boolean allowReport(){
        return hasPermission(SystemEnums.PERMISSION.REPORT);
    }//allowReport
    
    public boolean allowReport(--Object obj){
        return hasPermission(SystemEnums.PERMISSION.REPORT);
    }//allowReport

    /**
     * Permisos especiales
     * @return 
     */
    @Override
    public boolean allowSpecialAction(){
        return hasPermission(SystemEnums.PERMISSION.SPECIAL);
    }//allowSpecialAction

    public boolean allowSpecialAction(--Object obj){
        return hasPermission(SystemEnums.PERMISSION.SPECIAL);
    }//allowSpecialAction
    
    //</editor-fold>

    
    //------------------------------------------------------
    // Messages
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Messages">
    
    
    
    //</editor-fold>
    
    
    //------------------------------------------------------
    // Actions
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Actions">
    
    /**
     * Carga un elemento si este viene como parametro
     * @param id 
     */
    private void loadItemFromId(String id){
        try{
            if(id!=null && !id.isEmpty()){
                Long id_ = Long.valueOf(id);
                 obj = 
                
                if(obj!=null){
                   selectedObj = obj;
                   
                   
                } 
            }
            
        }catch(Exception ex){
            SystemLog.writeException(ex);
        }
    }//loadItemFromId
    
    
    /**
     * Regresa a la pagina de listado
     */
    public void back(){
        redirect("list.xhtml");    
    }//back
    
    
    
    /**
     * Prepara la vista y el bean para un Nuevo elemento
     */
    public void addItem(){
        if(allowAdd()){
           
            redirect("newEdit.xhtml?pageEd=true");      
        }else{
            reportProhibitedAction(SystemEnums.PERMISSION.ADD);
        }
           
        
    }//addItem
    
    /**
     * Guarda un elemento
     */
    public void saveItem(){
        if(allowSave()){
           
            try {
                save

                String msg = msg_item_save_success(selectedObj.getName());
                showSuccessMessage("", msg);
                
            } catch (CustomException-- ex) {
                showErrorMessage("", ex.getDescription());
            } catch (Exception ex){
                String msg = msg_item_save_error(selectedObj.getName());
                showErrorMessage("", msg);
            }
            
        }else{
            reportProhibitedAction(SystemEnums.PERMISSION.EDIT);
        }
    }//saveItem
    
    /**
     * Prepara la vista y el bean para un editar un elemento
     * @param obj 
     */
    public void editItem(--Object obj){
        if(allowEdit(obj)){
           if(obj!=null && obj.getId()!=null)
              redirect("newEdit.xhtml?pageEd=true&objId="+obj.getId());  
        }else{
            reportProhibitedAction(SystemEnums.PERMISSION.EDIT);
        }
    }//editItem
    
    
    /**
     * Prepara la vista y el bean para un visualizar un elemento sin guardar
     * @param obj 
     */
    public void viewItem(--Object obj){
        if(allowView(obj)){
           if(obj!=null && obj.getId()!=null)
              redirect("newEdit.xhtml?objId="+obj.getId());  
        }else{
            reportProhibitedAction(SystemEnums.PERMISSION.EDIT);
        }
    }//viewItem
    
    
    /**
     * Elimina un elemento
     * @param obj 
     */
    public void deleteItem(--Object obj){
        if(allowDelete(obj)){
          
            try {
                delete
                
                //Actualiza tabla
                
                
                String msg = msg_item_delete_success(obj.getName());
                showSuccessMessage("", msg);
                
            } catch (CustomException-- ex) {
                String msg = msg_item_delete_fail(obj.getName());
                showErrorMessage("", msg);
            } catch (Exception ex){
                String msg = msg_item_delete_error(obj.getName());
                showErrorMessage("", msg);
            }
            
        }else{
            reportProhibitedAction(SystemEnums.PERMISSION.DELETE);
        }
    }//deleteItem
    
    
    //</editor-fold>
    
    
    //------------------------------------------------------
    // None
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="None">
    
    //</editor-fold>
    
}//class
