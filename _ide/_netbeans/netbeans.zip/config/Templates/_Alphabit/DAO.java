/*******************************************************************************
 * ${name}DAO.java
 * ${name} Data Access Object
 * @tversion 2.0
 *
 *       @author  ${user}
 * @creationDate  ${date}
 * {nextEntry}
<#assign licenseFirst = " *******************************************************************************">
<#assign licensePrefix = " * ">
<#assign licenseLast = " *******************************************************************************/">
<#include "${myLicensePath}">

<#if package?? && package != "">
package ${package};
</#if>
import com.uxmalsoft.commons.exception.persistence.DBException;
import com.uxmalsoft.commons.exception.persistence.PersistenceException;
/*--------------------------------------------------------------------------
 @todo (eliminar al finalizar)
 0 Cambiar la ruta del Modelo (persistence.model.)
---------------------------------------------------------------------------*/
import com.uxmalsoft.persistence.SCHEMA.model.${name};


import com.uxmalsoft.commons.log.Console;
import com.uxmalsoft.commons.log.SystemLog;
import com.uxmalsoft.commons.utils.StringUtils;
import com.uxmalsoft.enums.SystemEnums;
import com.uxmalsoft.persistence.sys.dao.BaseDAO;
import com.uxmalsoft.persistence.sys.model.Organization;
import com.uxmalsoft.persistence.sys.model.User;
import java.sql.Array;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.StatelessSession;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import static com.uxmalsoft.commons.utils.StringUtils.isNotEmpty;
import static com.uxmalsoft.commons.utils.StringUtils.validateNull;

/**
 * <p>${name} Data Access Object</p>
 * @author  ${user}
 * @since   ${firstVersion}
 * @version ${version}
 */
/*========================================================================================
@todo CheckList (eliminar al finalizar)
 1 Cambiar el nombre de este archivo por el nombre del Objeto+DAO SIN REFACTOR
=========================================================================================*/
public class ${name}DAO extends BaseDAO<${name}>{

    //------------------------------------------------------
    // Attributes
    //------------------------------------------------------
    private ${name} entityClass;

    
    //------------------------------------------------------
    // Constructors
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Constructors">
    public ${name}DAO(String idOp) {
        super(${name}.class, idOp);
        config(true);
    }
    
    public ${name}DAO(boolean fusionNames, boolean caseSensitive, MatchMode matchMode){
        super(${name}.class);
        this.fusionNames        = fusionNames;
        this.caseSensitiveNames = caseSensitive;
        this.matchModeNames     = matchMode;
        config(false);
    }
    
    public ${name}DAO() {
        super(${name}.class);
        config(true);
    }
    
    /**
     * Configuracion del DAO
     * @param overrideNameAttrs 
     */
    private void config(boolean overrideNameAttrs){
        /*--------------------------------------------------------------------------
         @todo (eliminar al finalizar)
         2 Cambiar atributos de ordenamiento orderBy_1,2,3 (en DB se usa underscore_case
         3 Cambiar parametros de fusion de nombres:
           fusionNames,caseSensitiveNames,matchModeNames
        ---------------------------------------------------------------------------*/
        this.orderBy_1 = "a_column"; ORDER
        this.orderBy_2 = "a_column"; ORDER
        this.orderBy_3 = "a_column"; ORDER
        
        if(overrideNameAttrs){
            this.fusionNames        = false;
            this.caseSensitiveNames = false;
            this.matchModeNames     = MatchMode.ANYWHERE;
        }
    }//config
    
    //</editor-fold>
    
    
    //------------------------------------------------------
    // Getters & Setters
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Getters & Setters">
    
    public ${name} getEntityClass() {
        return entityClass;
    }

    public void setEntityClass(${name} entityClass) {
        this.entityClass = entityClass;
    }
    //</editor-fold>
    
    
    //------------------------------------------------------
    // Criteria
    //------------------------------------------------------
    /**
     * Crea Criteria Id In
     * @param ids
     * @param session
     * @return
     * @throws DBException 
     */
    private Criteria createCriteria_IdIn(Object[] ids, Session session) throws DBException {
        Criteria crit = null;
        try {
            crit = getDBSession().createCriteria(${name}.class);
            if (ids!=null && ids.length>0) {
                
                //ids
                crit.add(Restrictions.in("id", ids));
                //deleted
                crit.add(Restrictions.eq("deleted", false));

            }//!null
            /*--------------------------------------------------------------------------
             @todo (eliminar al finalizar)
             4 Cambiar atributos de ordenamiento en createCriteria_IdIn():
               dejarlos como ordenamiento orderBy_1,2,3 o personalizados
            ---------------------------------------------------------------------------*/
            crit.addOrder(Order.asc(orderBy_1)); ORDER
            crit.addOrder(Order.asc(orderBy_2)); ORDER
            crit.addOrder(Order.asc(orderBy_3)); ORDER
        } catch (Exception ex) {
            throw new DBException(ex);
        }
        return crit;
    }//createCriteria_IdIn
    
    
    /**
     * Crea Criteria
     * @param session
     * @return
     * @throws DBException 
     */
    private Criteria createCriteria(Session session) throws DBException {
        Criteria crit = null;
        try {
            crit = getDBSession().createCriteria(${name}.class);
            if (entityClass != null) {
                
                //Nombre
                Criterion names = createNameCriteria();
                if(names!=null)
                   crit.add(names);

                /*--------------------------------------------------------------------------
                 @todo (eliminar al finalizar)
                 5 Cambiar criteria en createCriteria()
                   - validar que el atributo no sea null o venga vacio para Strings
                   - validar que el atributo no sea null y sea >0 o >-1 en numericos
                   - de preferencia usar ilike en Strings
                 ---------------------------------------------------------------------------*/
                CAMBIAR CRITERIA
                /*
                if (isNotEmpty(getEntityClass().getEmail())) {
                    crit.add(Restrictions.ilike("email", getEntityClass().getEmail(), MatchMode.START));
                }
                if (isNotEmpty(getEntityClass().getUsername())) {
                    crit.add(Restrictions.eq("username", getEntityClass().getUsername()));
                }
               
                if (entityClass.getStatus() != null && entityClass.getStatus()>0) {
                    crit.add(Restrictions.eq("status", entityClass.getStatus()));
                }
                
                if (entityClass.getType()!= null) {
                    crit.add(Restrictions.eq("type", entityClass.getType()));
                }
                */
                
                //Ref
                if (entityClass.getIdOrg()!=null && entityClass.getIdOrg().getId()!= null && entityClass.getIdOrg().getId()>0) {
                    crit.add(Restrictions.eq("id_org.id", entityClass.getIdOrg().getId()));
                }
                
                //deleted
                crit.add(Restrictions.eq("deleted", false));

            }//!null
            /*--------------------------------------------------------------------------
             @todo (eliminar al finalizar)
             6 Cambiar atributos de ordenamiento en createCriteria():
               dejarlos como ordenamiento orderBy_1,2,3 o personalizados
            ---------------------------------------------------------------------------*/
            crit.addOrder(Order.asc(orderBy_1)); ORDER
            crit.addOrder(Order.asc(orderBy_2)); ORDER
            crit.addOrder(Order.asc(orderBy_3)); ORDER
        } catch (Exception ex) {
            throw new DBException(ex);
        }
        return crit;
    }//createCriteria

    /**
     * Crea Criteria para nombres que se distribuyen en varias columnas
     * @return
     * @throws DBException 
     */
    private Criterion createNameCriteria() throws DBException {

        Criterion crit = null;
        
        try {
            if (entityClass != null) {
                /*En el caso especial de la busqueda por nombres
                  se pueden omitir acentos y no distinguir entre mayusculas y minusculas
                */
                
                /*--------------------------------------------------------------------------
                 @todo (eliminar al finalizar)
                 7 Seleccionar el atributo que contiene el valor de busqueda para fusionar nombres
                   en createNameCriteria (ej. apP, aM, nombre LIKE nombre)

                 8 Seleccionar los atributos e indicar el nombre de la columna, que forman los nombres
                   en createNameCriteria (ej, 'nombre' .getNombre() - 'razonS' .getRazonS() - 'apP' getApP()
                ---------------------------------------------------------------------------*/
                List<String[]> attrs = new ArrayList<>();
                String fusionValue = getEntityClass().;   //Valor para comparar los nombre de fusion
                
                //Column/Value
                attrs.add(StringUtils.asStringArray("a_column",getEntityClass().));  
                attrs.add(StringUtils.asStringArray("a_column",getEntityClass().));
                attrs.add(StringUtils.asStringArray("a_column",getEntityClass().));

                
                //Executa la fusion
                crit = executeFusionNames(attrs, fusionValue, fusionNames, caseSensitiveNames, matchModeNames);
            }//!null
            
        } catch (Exception ex) {
            throw new DBException(ex);
        }
        return crit;
    }//createNameCriteria

    
    /**
     * Prueba de Critera 
     * @param fusionNames
     * @param caseSensitive
     * @param matchMode 
     */
    public static void testCriteria(boolean fusionNames, boolean caseSensitive, MatchMode matchMode) {
        ${name}  obj = new ${name}();
        
        ${name}DAO  dao = new ${name}DAO();
        dao.setFusionNames(fusionNames);
        dao.setCaseSensitiveNames(caseSensitive);
        dao.setMatchModeNames(matchMode);
        
        try {
            dao.findAll();
        } catch (DBException ex) {
            Console.writeDebug(""+ex, false);
        }
    }//testCriteria
    
    
    //------------------------------------------------------
    // Find
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Find">
    
    /**
     * Limpia todos los atributos usados en criteria
     * @param obj
     * @return 
     */
    public ${name} reset4Criteria(${name} obj){
        if(obj==null)obj=new ${name}();
        obj.setIdOrg(null);
        /*--------------------------------------------------------------------------
         @todo (eliminar al finalizar)
         9 Poner valores neutros a los atributos usados en criteria
           - toda busqueda usara esta funcion primero
        ---------------------------------------------------------------------------*/
        obj.("");
        obj.(null);
        
        return obj;
    }//reset4Criteria
    
    /**
     * Lista todos los elementos
     * @return
     * @throws DBException 
     */
    public List findAll() throws DBException {
        List<${name}> list = new ArrayList<${name}>();
        try {
            ${name} obj = reset4Criteria(new ${name}());
            list = findByCriteria(obj);
            
        } catch (DBException ex) {
            throw new DBException(ex.getError());
        }
        return list;
    }//findAll
    
    /**
     * Find todos los elementos con id IN (ids)
     * @param ids
     * @return
     * @throws DBException 
     */
    public List findBy_IdIn(Object[] ids) throws DBException{
        List<${name}> list = new ArrayList<${name}>();
        try {
            Session session = getDBSession();
            setCriteria(createCriteria_IdIn(ids,session));
            list = find();
        } catch (DBException ex) {
            throw new DBException(ex.getError());
        }
        return list;
    }//findBy_IdIn
    
    
    /*--------------------------------------------------------------------------
     @todo (eliminar al finalizar)
     10 Ejemplo de busqueda para un atributo en especial (comentar para uso futuro)
        - se llama a reset4Criteria
        - se asigna el atributo de busqueda
    ---------------------------------------------------------------------------*/
    /**
     * Busca por algo
     * @param 
     * @return
     * @throws DBException 
     */
    public ${name} findByAlgo(Object param) throws DBException{
        ${name} obj = null;
        try{
            obj = reset4Criteria(new ${name}());
            obj.set
            
            List<${name}> list = findByCriteria(obj);
            if(list!=null && list.size()>0)
               obj = list.get(0);
            else
               obj = null;
        }catch(DBException ex){
            obj = null;
            throw new DBException(ex.getError());
        }
    
        return obj;
    }//findByAlgo

    public List<${name}> findByAlgo(Object param) throws DBException{
        List<${name}> list = new ArrayList<${name}>();
        try{
            ${name} obj = reset4Criteria(new ${name}());
            obj.set
            
            list = findByCriteria(obj);
            
        }catch(DBException ex){
            throw new DBException(ex.getError());
        }
    
        return list;
    }//findByAlgo
    
    
    /**
     * Find
     * @return
     * @throws DBException 
     */
    public List findByCriteria() throws DBException {
        List<${name}> list = new ArrayList<${name}>();
        try {
            Session session = getDBSession();
            setCriteria(createCriteria(session));
            list = find();
        } catch (DBException ex) {
            throw new DBException(ex.getError());
        }
        return list;
    }//findByCriteria
    
    /**
     * Find
     * @param objSearch
     * @return
     * @throws DBException 
     */
    public List findByCriteria(${name} objSearch) throws DBException {
        setEntityClass(objSearch);
        return findByCriteria();
    }//findByCriteria
    
    /**
     * Find
     * @param maxResult
     * @param firstResult
     * @return
     * @throws DBException 
     */
    public List findByCriteria(int maxResult, int firstResult)
            throws DBException {
        List<${name}> list = new ArrayList();
        try {
            Session session = getDBSession();
            setCriteria(createCriteria(session));
            list = find(maxResult, firstResult);
        } catch (DBException ex) {
            throw new DBException(ex.getError());
        }
        return list;
    }//findByCriteria
    
    /**
     * Find
     * @param objSearch
     * @param maxResult
     * @param firstResult
     * @return
     * @throws DBException 
     */
    public List findByCriteria(${name} objSearch, int maxResult, int firstResult)
            throws DBException {
        setEntityClass(objSearch);
        return findByCriteria(maxResult, firstResult);
    }//findByCriteria
    //</editor-fold>
    
    
    //------------------------------------------------------
    // Count
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Count">
    /**
     * Count
     * @return
     * @throws DBException 
     */
    public int getItemsCount() throws DBException {
        Integer count = 0;
        Criteria crit = null;
        Session session = null;
        try {
            session = getDBSession();
            setCriteria(createCriteria(session));
            count = count();
        } catch (DBException ex) {
            count = -1;
            throw new DBException(ex.getError());
        }
        return count;
    }//getItemsCount
    
    /**
     * Count
     * @param objSearch
     * @return
     * @throws DBException 
     */
    public int getItemsCount(${name} objSearch) throws DBException {
        setEntityClass(objSearch);
        return getItemsCount();
    }//getItemsCount
    
    
    //</editor-fold>


    //------------------------------------------------------
    // Save
    //------------------------------------------------------   
    /**
     * Create or Update
     * @param obj
     * @param usr
     * @return
     * @throws PersistenceException 
     */
    public boolean save(${name} obj , User usr)
            throws PersistenceException {
        boolean res = false;
        
        try {
            if(obj.getId().equals(0L)){
               obj.setCreationDate(new Date());
               if(usr!=null)
                  obj.setCreatedBy(usr.getId());
            }else{
               obj.setLastUpdate(new Date());
               if(usr!=null)
                  obj.setModifiedBy(usr.getId());
            }
            
            res = createUpdate(obj);    
        } catch (DBException ex) {
            throw new DBException(ex.getError());
        }
        return res;
    }//save
    


    //------------------------------------------------------
    // Delete
    //------------------------------------------------------
    
    /**
     * Elimina
     * @param obj
     * @param usr
     * @return
     * @throws PersistenceException 
     */
    public boolean delete(${name} obj , User usr)
            throws PersistenceException {
        boolean res = false;
        
        try {
            //Borrado Logico (deleted=true, lastUpdate, modifiedBy)
            obj.setDeleted(true);
            save(obj,usr);

            /*--------------------------------------------------------------------------
             @todo (eliminar al finalizar)
             11 Determinar si es Eliminacion Logica, para que guarde
                lastUpdate, modifiedBy y deleted = true
                o es Eliminacion Definitiva
            ---------------------------------------------------------------------------*/

            //Borrado No Logico
            res = delete(obj.getId(), false);    
        } catch (DBException ex) {
            throw new DBException(ex.getError());
        }
        return res;
    }//delete


    //------------------------------------------------------
    // Queries
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Queries">

    /*--------------------------------------------------------------------------
     @todo (eliminar al finalizar)
     12 Ejemplos de doExecuteSQLQuery(), doSQLQueryMapResult() para trbajar con
        queries, executando update/delete o una query regresando un Map
        - comentar para uso futuro
     ---------------------------------------------------------------------------*/

    /**
     * 
     * 
     * @throws PersistenceException 
     */
    /*
    public boolean example(${name} obj)
            throws PersistenceException {
        boolean res = false;
        StringBuilder sb = new StringBuilder();
        StatelessSession session = null;
        
        try {
            if(obj!=null){
                session = getDBStatelessSession();

                sb.append(" DELETE FROM ").append(${name}.getSchemaTable());
                sb.append(" WHERE id_user = :idAAA ");

                //New Query
                SQLQuery q = session.createSQLQuery(sb.toString());

                q.setLong("idAAA" , obj.getId());

                //Ejecuta Update
                doExecuteSQLQuery(q);


                res = true;
            }//if
            
        } catch (DBException ex) {
            throw new DBException(ex.getError());
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return res;
    }*/

    /**
     * 
     * 
     * @throws DBException 
     */
    /*
    public List exampleFindId() throws DBException {
        List<${name}> list = new ArrayList<${name}>();
        StringBuilder sb = new StringBuilder();
        StatelessSession session = null;
        
        try {
            session = getDBStatelessSession();

            sb.append(" SELECT id FROM ").append(${name}.getSchemaTable()).append(" ak ");
            sb.append(" WHERE ak.a_field=:aField ");
            

            //New Query
            SQLQuery q = session.createSQLQuery(sb.toString());
            q.setInteger("aField" , 0);
            
            //Consulta
            List<Map> list_temp = doSQLQueryMapResult(q);
            
            Object[] ids = getIds_fromResult(list_temp);
            list = findBy_IdIn(ids);

        } catch (Exception ex) {
            throw new DBException(""+ex);
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return list;
    }*/
    
    //</editor-fold>
    
}//class