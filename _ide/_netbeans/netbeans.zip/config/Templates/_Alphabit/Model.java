/*******************************************************************************
 * ${nameAndExt}
 * Modelo de ${name} 
 * @tversion 2.0
 *
 *       @author  ${user}
 * @creationDate  ${date}
 * {nextEntry}
<#assign licenseFirst = " *******************************************************************************">
<#assign licensePrefix = " * ">
<#assign licenseLast = " *******************************************************************************/">
<#include "${myLicensePath}">

<#if package?? && package != "">
package ${package};
</#if>
import static com.uxmalsoft.commons.utils.StringUtils.isNotEmpty;
import static com.uxmalsoft.commons.utils.StringUtils.validateNull;

import com.uxmalsoft.commons.log.Console;
import com.uxmalsoft.commons.log.SystemLog;
import com.uxmalsoft.enums.SystemEnums;
import com.uxmalsoft.persistence.sys.model.Organization;
import java.io.Serializable;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import org.hibernate.annotations.SQLDelete;


/**
 * <p>${name} Model</p>
 * @author  ${user}
 * @since   ${firstVersion}
 * @version ${version}
 */
@Entity
@Table(name = "--schema.--tableName") 
/*=========================================================================================
@todo CheckList (eliminar al finalizar)
 1 Reemplazar --schema por el Esquema de la Tabla (Ctrl+H)
 2 Reemplazar --tableName por el nombre de la Tabla (Ctrl+H)
=========================================================================================*/
public class ${name} implements Serializable {

    //------------------------------------------------------
    // Attributes
    //------------------------------------------------------
    private static final long serialVersionUID = 1L;
    private static final String schema    = "--schema";
    private static final String tableName = "--tableName";
    private static final String schemaTable = "--schema.--tableName";
    
    @Id
    @NotNull
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id = 0L;

    @ManyToOne
    @JoinColumn(name="id_org", nullable = false)
    private Organization idOrg = null;
    
    /*--------------------------------------------------------------------------
     @todo (eliminar al finalizar)
     4 Colocar Atributos SIN inicializarlos, 
       - los atributos usaran notacion camelCase
       - especificar el nombre de la columna (name=""... la cual esta en underscore_case en db
       - usar Integer, Long y Short en vez de int, long, short, 
       - usar boolean como primitivo a menos que sea necesario
       - colocar atributos OneToMany y Transient con sus respectivos anotaciones
       - no usar palabras reservadas de SQL como alias, from, etc
     ---------------------------------------------------------------------------*/
    /*
    @Column(name="a_string", nullable = false, length = 10)
    private String aString;
    
    @Column(name="a_long", nullable = false)
    private Long aLong;

    @Column(name="a_integer", nullable = false)
    private Integer aInteger;

    @Column(name="a_short", nullable = false)
    private Short aShort;

    @Column(name="a_boolean", nullable = false)
    private boolean aBoolean;
    */

    @Column(name="created_by", nullable = true)
    private Long createdBy = null;

    @Column(name="modified_by", nullable = true)
    private Long modifiedBy = null;

    @Column(name="creation_date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date creationDate = new Date();
    
    @Column(name="last_update", nullable = true)
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate = null;

    @Column(nullable = false)
    private boolean imported = false;

    @Column(nullable = false)
    private boolean deleted = false;
    
    //--------------------------------
    //OneToMany
    //--------------------------------

    //--------------------------------
    //Transient
    //--------------------------------

    
    //------------------------------------------------------
    // Constructors
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Constructors">
    public ${name}(){
        this.idOrg = null;
        this.createdBy = null;
        this.modifiedBy = null;

        /*--------------------------------------------------------------------------
         @todo (eliminar al finalizar)
         7 Incluir la inicializacion de Parametros del Constructor Parmetrizado 
           en constructor default
           - colocarles un valor inicial vacio ("", null, -1 )
           - si existen valores default (enumeracion) de algun atributo inicializarlo aqui
           - Decidir si referencias hacia otros POJO´s se inicializan en null o se crea obj vacio
         ---------------------------------------------------------------------------*/
        
    }//empty

    /*--------------------------------------------------------------------------
     @todo (eliminar al finalizar)
     5 Crear Constructor Parametrizado (Ctrl+Insert) SIN los siguientes atributos: 
       id, idOrg, createdBy,modifiedBy, creationDate, lastUpdate, imported, deleted
       - Decidir si referencias hacia otros POJO´s son necesarios en constructor

     6 Incluir referecia a constructor default 'this();' en constructor parmetrizado
     ---------------------------------------------------------------------------*/

    public ${name}(${name} obj){
        if(obj!=null){
            this.idOrg      = obj.getIdOrg();
            this.createdBy  = obj.getCreatedBy();
            this.modifiedBy = obj.getModifiedBy();

            //Decidir si referencias hacia otros POJO´s se copian o 
            //se generan nuevos objetos para ellos tambien

            /*--------------------------------------------------------------------------
             @todo (eliminar al finalizar)
             9 Especificar los Atributos restantes en Constructor de Copia
              (primero generar Getters & Setters)
             ---------------------------------------------------------------------------*/

            //Decidir si creationDate,lastUpdate,deleted e imported, se reinician o se copian
            //this.creationDate = obj.getCreationDate();
            //this.lastUpdate = obj.getLastUpdate();
            this.imported = obj.isImported();
            //this.deleted = obj.isDeleted();
        }
    }//constructor copia

    //</editor-fold>
    

    //------------------------------------------------------
    // Getters & Setters
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Getters & Setters">
    
    public static String getSchema() {
        return schema;
    }
    public static String getTableName() {
        return tableName;
    }
    public static String getSchemaTable() {
        return schemaTable;
    }

    public Long getId(){
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Organization getIdOrg() {
        return idOrg;
    }

    public void setIdOrg(Organization idOrg) {
        this.idOrg = idOrg;
    }

    /*--------------------------------------------------------------------------
     @todo (eliminar al finalizar)
     8 Construir Getters y Setters (Ctrl+Insert)
       - Getters & Setters de OneToMany y Transient tienen su seccion
     ---------------------------------------------------------------------------*/

    public Long getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Long createdBy) {
        this.createdBy = createdBy;
    }

    public Long getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Long modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public boolean isImported() {
        return imported;
    }

    public void setImported(boolean imported) {
        this.imported = imported;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    //--------------------------------
    //OneToMany
    //--------------------------------

    //--------------------------------
    //Transient
    //--------------------------------

    //</editor-fold>
    
    //------------------------------------------------------
    // Methods and Functions
    //------------------------------------------------------
    
    /**
     * Regresa una copia del Objeto
     * @return 
     */
    public ${name} asCopy(){
        ${name} obj = new ${name}();
        obj.setIdOrg(this.idOrg);
        obj.setCreatedBy(this.createdBy);
        obj.setModifiedBy(this.modifiedBy);

        //Decidir si referencias hacia otros POJO´s se regresan o 
        //se generan nuevos objetos para ellos tambien
        
        /*--------------------------------------------------------------------------
         @todo (eliminar al finalizar)
         10 Adecuar funcion asCopy() con los atributos restantes
         ---------------------------------------------------------------------------*/

        //Decidir si creationDate,lastUpdate,deleted e imported, se copian o reinician valores
        //obj.setCreationDate(this.creationDate);
        //obj.setLastUpdate(this.lastUpdate);
        obj.setImported(this.imported);
        //obj.setDeleted(this.deleted);

        return obj;
    }//asCopy


    /**
     * Regresa una lista as Map
     * @return 
     */
     public static Map list_asMap(List<${name}> list){
        Map map = new LinkedHashMap();
        
        /*--------------------------------------------------------------------------
         @todo (eliminar al finalizar)
         11 Adecuar funcion list_asMap() para especificar un Map de [valor, id]
         ---------------------------------------------------------------------------*/
        for (${name} item : list) {
            map.put(item.getName(),item.getId());
        }
        return map;
    }//list_asMap

    /*--------------------------------------------------------------------------
     @todo (eliminar al finalizar)
     12 Generar hashCode & equals (Ctrl+Insert) indicando el atributo(s) 
        para identificar objetos iguales (por default usar id)
     ---------------------------------------------------------------------------*/


    /*--------------------------------------------------------------------------
     @todo (eliminar al finalizar)
     13 Generar toString (Ctrl+Insert) SIN los atributos: 
        createdBy,modifiedBy, deleted
     ---------------------------------------------------------------------------*/

    /*--------------------------------------------------------------------------
     @todo (eliminar al finalizar)
     14 Adecuar toString para objetos no primitivos 
        ej (idOrg -> idOrg.getName())
     ---------------------------------------------------------------------------*/
    
}//class
