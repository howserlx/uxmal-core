/*******************************************************************************
 * ${nameAndExt}
 * Description
 *
 *       @author  ${user}
 * @creationDate  ${date}
 *
 * @dependencies
 * {nextEntry}
<#assign licenseFirst = " *******************************************************************************">
<#assign licensePrefix = " * ">
<#assign licenseLast = " *******************************************************************************/">
<#include "${myLicensePath}">

<#if package?? && package != "">
package ${package};
</#if>
import static com.uxmalsoft.commons.utils.StringUtils.isNotEmpty;
import static com.uxmalsoft.commons.utils.StringUtils.validateNull;

import com.uxmalsoft.commons.log.*;
import com.uxmalsoft.commons.conf.TestParams;
import java.util.Date;


/**
 * <p>Description</p>
 * @author  ${user}
 * @since   ${firstVersion}
 * @version ${version}
 */
public class ${name} {

    //------------------------------------------------------
    // Attributes
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Attributes">
    
    //</editor-fold>
    
    //------------------------------------------------------
    // Constructors
    //------------------------------------------------------
    private ${name}(){
        //Only public static functions
    }//empty
    
    
    //------------------------------------------------------
    // Methods and Functions
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Methods and Functions">

    private static void aMethod(){
        try {
            
        } catch (Exception ex) {
            SystemLog.writeUtilsException(ex);
        }
    }//aMethod
    

    //</editor-fold>
    

    //------------------------------------------------------
    // main
    //------------------------------------------------------
    //<editor-fold defaultstate="open" desc="main">
    /**
     * 
     * @param args 
     */
    public static void main(String[] args) {
        try {
            
            SystemLog.initialize(TestParams.LOG_CONFIG_PATH,true);
            Console.writeInfo(Console.SEPARATOR_LINE);
            Console.writeInfo(" Test de ******** - "+new Date().toString(), true);
            Console.writeInfo(Console.SEPARATOR_LINE);
            
        } //main
        catch (Exception ex) {
            System.out.println(""+ex);
        }
    }
    //</editor-fold>


    //------------------------------------------------------
    // None
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="None">
    
    //</editor-fold>
    
}//class
