/*******************************************************************************
 * ${nameAndExt}
 * Description
 *
 *       @author  ${user}
 * @creationDate  ${date}
 * {nextEntry}
<#assign licenseFirst = " *******************************************************************************">
<#assign licensePrefix = " * ">
<#assign licenseLast = " *******************************************************************************/">
<#include "${myLicensePath}">

<#if package?? && package != "">
package ${package};
</#if>
import static com.uxmalsoft.commons.utils.StringUtils.isNotEmpty;
import static com.uxmalsoft.commons.utils.StringUtils.validateNull;

import com.uxmalsoft.commons.log.*;


/**
 * <p>Description</p>
 * @author  ${user}
 * @since   ${firstVersion}
 * @version ${version}
 */
public class ${name} {

    //------------------------------------------------------
    // Attributes
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Attributes">
    
    //</editor-fold>
    
    //------------------------------------------------------
    // Constructors
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Constructors">
    public ${name}(){
    
    }//empty
    //</editor-fold>
    
    //------------------------------------------------------
    // Getters & Setters
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Getters & Setters">
    
    //</editor-fold>
    
    //------------------------------------------------------
    // Methods and Functions
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Methods and Functions">
    /**
     * Description
     * @param param1
     * @param param2 
     */
    public void aMethod(Object param1, Object param2){
        try {
            
        } catch (Exception ex) {
            SystemLog.writeException(ex);
        }
    }//aMethod
    
    /**
     * Description
     * @param param1
     * @param param2
     * @return 
     */
    public boolean aReturnMethod(Object param1, Object param2){
        boolean res = false;
        try {
            //TO DO
            //res sets to ´false' value is a good programming practice
        } catch (Exception ex) {
            SystemLog.writeException(ex);
        }
        return res;
    }//aReturnMethod

    //</editor-fold>
    
    //------------------------------------------------------
    // main
    //------------------------------------------------------
    //<editor-fold defaultstate="open" desc="main">
    /**
     * 
     * @param args 
     */
    public static void main(String[] args) {
        //TO DO
    }//main
    //</editor-fold>

    //------------------------------------------------------
    // None
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="None">
    
    //</editor-fold>
    
}//class
