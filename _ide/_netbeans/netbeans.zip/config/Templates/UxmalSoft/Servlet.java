/*******************************************************************************
 * ${nameAndExt}
 * Servlet Description
 *
 *       @author  ${user}
 * @creationDate  ${date}
 * {nextEntry}
<#assign licenseFirst = " *******************************************************************************">
<#assign licensePrefix = " * ">
<#assign licenseLast = " *******************************************************************************/">
<#include "${myLicensePath}">

<#if package?? && package != "">
package ${package};
</#if>
import static com.uxmalsoft.commons.utils.StringUtils.isNotEmpty;
import static com.uxmalsoft.commons.utils.StringUtils.validateNull;

import com.uxmalsoft.commons.log.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * <p>Servlet Description</p>
 * @author  ${user}
 * @since   ${firstVersion}
 * @version ${version}
 */
@WebServlet(name="${name}", urlPatterns={"/${name}"} )
public class ${name} extends HttpServlet {

    //------------------------------------------------------
    // Attributes
    //------------------------------------------------------
    private String resp;

    
    //------------------------------------------------------
    // Init
    //------------------------------------------------------
    //<editor-fold desc="Init">
    @Override
    public void init() throws ServletException
    {
        // Do required initialization
        resp = "";
    }//init
    
    //</editor-fold>
    

    //------------------------------------------------------
    // HttpServlet Methods
    //------------------------------------------------------
    // <editor-fold defaultstate="collapsed" desc="HttpServlet Methods">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    
    
    @Override
    public String getServletInfo() {
        return "";
    }

    //</editor-fold>

    
    //------------------------------------------------------
    // Methods and Functions
    //------------------------------------------------------
    //<editor-fold desc="Methods and Functions">
    
    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try{
            //Params
            String param = request.getParameter("param");
            

            // Set response content type
            response.setContentType("text/html");

            // Actual logic goes here.
            PrintWriter out = response.getWriter();

            

            out.println(resp);
        }catch(Exception ex){
            SystemLog.writeException(ex);
        }
    }//processRequest

    //</editor-fold>
    
    
    //------------------------------------------------------
    // Destroy
    //------------------------------------------------------
    //<editor-fold desc="Destroy">
    @Override
    public void destroy()
    {
        // do nothing.
    }//destroy
    
    //</editor-fold>
    
    //------------------------------------------------------
    // None
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="None">
    
    //</editor-fold>
    
}//class
