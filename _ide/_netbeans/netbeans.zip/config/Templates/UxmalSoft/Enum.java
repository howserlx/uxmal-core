/*******************************************************************************
 * ${nameAndExt}
 * Enum
 *
 *       @author  ${user}
 * @creationDate  ${date}
 * {nextEntry}
<#assign licenseFirst = " *******************************************************************************">
<#assign licensePrefix = " * ">
<#assign licenseLast = " *******************************************************************************/">
<#include "${myLicensePath}">

<#if package?? && package != "">
package ${package};
</#if>
import static com.uxmalsoft.commons.utils.StringUtils.isNotEmpty;
import static com.uxmalsoft.commons.utils.StringUtils.validateNull;

import java.util.LinkedHashMap;
import java.util.Map;


/**
 * <p>Enum</p>
 * @author  ${user}
 * @since   ${firstVersion}
 * @version ${version}
 */
public enum ${name} {

    DEFAULT ( 0, ""),   //Valor default (no asignado, estado nulo, etc)
    ITEM_01 ( 1, ""),
    ITEM_02 ( 2, ""),
    ITEM_03 ( 3, ""),
    ITEM_04 ( 4, ""),
    ;
    
    private final int id;
    private final String label;

    private ${name}(int id, String label){
        this.id    = id;
        this.label = label;
    }//constructor

    //------------------------------------------------------
    // Getters & Setters
    //------------------------------------------------------
    //<editor-fold desc="Getters & Setters">
    public String getName() {return this.name();}
    public int getId() {return id;}
    public String getLabel() {return label;}

    //</editor-fold>
   
    
    //------------------------------------------------------
    // Methods and Functions
    //------------------------------------------------------
    //<editor-fold desc="Methods and Functions">
    public static ${name} findById(int searchId){
        for (${name} item : ${name}.values()) {
            if(item.getId()== searchId)
               return item;
        }
        return DEFAULT;
    }//findById
    
    public static Map asMap(){
        Map map = new LinkedHashMap();
        for (${name} item : ${name}.values()) {
            map.put(item.getLabel(),item.getId());
        }
        return map;
    }//asMap

    //</editor-fold>
    
    //------------------------------------------------------
    // None
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="None">
    
    //</editor-fold>

}//enum
