/*******************************************************************************
 * ${nameAndExt}
 * Description
 *
 *       @author  ${user}
 * @creationDate  ${date}
 * {nextEntry}
<#assign licenseFirst = " *******************************************************************************">
<#assign licensePrefix = " * ">
<#assign licenseLast = " *******************************************************************************/">
<#include "${myLicensePath}">

<#if package?? && package != "">
package ${package};
</#if>

/**
 * <p>Description</p>
 * @author  ${user}
 * @since   ${firstVersion}
 * @version ${version}
 */
public interface ${name} {

    //------------------------------------------------------
    // Attributes
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Attributes">
    
    //</editor-fold>
    
    
    //------------------------------------------------------
    // Methods and Functions
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Methods and Functions">

    //</editor-fold>
    
}//interface
