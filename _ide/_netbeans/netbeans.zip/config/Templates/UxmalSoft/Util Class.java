/*******************************************************************************
 * ${nameAndExt}
 * Description
 *
 *       @author  ${user}
 * @creationDate  ${date}
 *
 * @dependencies
 * {nextEntry}
<#assign licenseFirst = " *******************************************************************************">
<#assign licensePrefix = " * ">
<#assign licenseLast = " *******************************************************************************/">
<#include "${myLicensePath}">

<#if package?? && package != "">
package ${package};
</#if>
import static com.uxmalsoft.commons.utils.StringUtils.isNotEmpty;
import static com.uxmalsoft.commons.utils.StringUtils.validateNull;

import com.uxmalsoft.commons.log.*;
import com.uxmalsoft.commons.conf.Params;



/**
 * <p>Description</p>
 * @author  ${user}
 * @since   ${firstVersion}
 * @version ${version}
 */
public class ${name} {

    //------------------------------------------------------
    // Attributes
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Attributes">
    
    //</editor-fold>
    
    //------------------------------------------------------
    // Constructors
    //------------------------------------------------------
    private ${name}(){
        //Only public static functions
    }//empty
    
    
    //------------------------------------------------------
    // Methods and Functions
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="Methods and Functions">
    /**
     * Description
     * @param param1
     * @param param2 
     */
    private static void aMethod(Object param1, Object param2){
        try {
            
        } catch (Exception ex) {
            SystemLog.writeUtilsException(ex);
        }
    }//aMethod
    
    /**
     * Description
     * @param param1
     * @param param2
     * @return 
     */
    private static boolean aReturnMethod(Object param1, Object param2){
        boolean res = false;
        try {
            //TO DO
            //res sets to ´false' value is a good programming practice
        } catch (Exception ex) {
            SystemLog.writeUtilsException(ex);
        }
        return res;
    }//aReturnMethod

    //</editor-fold>
    
    //------------------------------------------------------
    // None
    //------------------------------------------------------
    //<editor-fold defaultstate="collapsed" desc="None">
    
    //</editor-fold>
    
}//class
